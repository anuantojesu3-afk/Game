# Ultimate Shooter

A standalone GitHub-ready Python/Pygame prototype combining the systems discussed:
player movement, sprinting, shooting, weapons, enemies, rarities, mutations, buffs/debuffs,
Boss/Raid Boss/Final Boss, GOD/SECRET/ADMIN entities, XP, levels, currency, waves,
drops, missions, inventory, reports, Admin/Owner panels, leaderboard and secrets.

## Run
pip install -r requirements.txt
python main.py

Controls:
WASD movement | Mouse aim | Left click shoot | R reload | Space sprint
1/2/3 weapon | F1 report demo | F2 Admin panel | F3 Owner panel | Esc close panel

The local prototype uses OWNER role so every administrative feature can be tested.
For a real multiplayer release, authentication and authorization must be server-side.
