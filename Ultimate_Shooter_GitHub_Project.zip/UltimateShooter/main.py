import pygame, random, math, json
from pathlib import Path

pygame.init()
WIDTH, HEIGHT = 1100, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ultimate Shooter")
clock = pygame.time.Clock()
FONT = pygame.font.Font(None, 24)
BIG = pygame.font.Font(None, 42)
SAVE = Path("save.json")

RARITIES = [
    ("Common",1),("Uncommon",1.5),("Rare",2),("Epic",3),
    ("Legendary",5),("Mythic",8),("Divine",15),("GOD",40),
    ("SECRET",100),("ADMIN",250)
]
MUTATIONS = [
    ("None",1),("5x",5),("10x",10),("50x",50),("100x",100),
    ("500x",500),("1000x",1000),("Infinity",10000),
    ("Absolute Infinity",100000),("Beyond Absolute Infinity",1000000)
]
WEAPONS = [
    {"name":"Pistol","damage":22,"rate":.28,"mag":12,"reload":1.0},
    {"name":"Rifle","damage":12,"rate":.09,"mag":30,"reload":1.5},
    {"name":"Shotgun","damage":55,"rate":.65,"mag":6,"reload":1.8},
    {"name":"Sniper","damage":120,"rate":1.2,"mag":5,"reload":2.0},
    {"name":"Launcher","damage":180,"rate":1.5,"mag":3,"reload":2.4},
]

def load_data():
    if SAVE.exists():
        try: return json.loads(SAVE.read_text())
        except: pass
    return {"name":"Player","role":"OWNER","level":1,"xp":0,"coins":0,
            "kills":0,"high_wave":0,"discovered":0}

def save_data(data):
    SAVE.write_text(json.dumps(data,indent=2))

def weighted_rarity():
    r=random.random()
    thresholds=[(.55,"Common"),(.75,"Uncommon"),(.88,"Rare"),(.95,"Epic"),
                (.98,"Legendary"),(.992,"Mythic"),(.998,"Divine"),
                (.9995,"GOD"),(.9999,"SECRET")]
    for limit,name in thresholds:
        if r<limit:return name
    return "ADMIN"

def weighted_mutation():
    r=random.random()
    if r<.80:return "None"
    if r<.90:return "5x"
    if r<.95:return "10x"
    if r<.975:return "50x"
    if r<.99:return "100x"
    if r<.997:return "500x"
    if r<.999:return "1000x"
    if r<.9997:return "Infinity"
    if r<.99995:return "Absolute Infinity"
    return "Beyond Absolute Infinity"

class Player:
    def __init__(self):
        self.x,self.y=WIDTH/2,HEIGHT/2
        self.hp,self.max_hp=100,100
        self.speed=260
        self.weapon=0
        self.ammo=[w["mag"] for w in WEAPONS]
        self.cooldown=0
        self.reload=0
        self.data=load_data()
    def update(self,dt):
        keys=pygame.key.get_pressed()
        dx=(1 if keys[pygame.K_d] else 0)-(1 if keys[pygame.K_a] else 0)
        dy=(1 if keys[pygame.K_s] else 0)-(1 if keys[pygame.K_w] else 0)
        m=math.hypot(dx,dy) or 1
        sprint=keys[pygame.K_SPACE]
        sp=self.speed*(1.65 if sprint else 1)
        self.x=max(20,min(WIDTH-20,self.x+dx/m*sp*dt))
        self.y=max(75,min(HEIGHT-20,self.y+dy/m*sp*dt))
        self.cooldown=max(0,self.cooldown-dt)
        if self.reload>0:
            self.reload-=dt
            if self.reload<=0:self.ammo[self.weapon]=WEAPONS[self.weapon]["mag"]
    def shoot(self,bullets):
        if self.reload>0 or self.cooldown>0 or self.ammo[self.weapon]<=0:return
        w=WEAPONS[self.weapon]
        self.cooldown=w["rate"];self.ammo[self.weapon]-=1
        mx,my=pygame.mouse.get_pos()
        a=math.atan2(my-self.y,mx-self.x)
        bullets.append(Bullet(self.x,self.y,a,w["damage"]))
    def reload_weapon(self):
        if self.reload<=0 and self.ammo[self.weapon]<WEAPONS[self.weapon]["mag"]:
            self.reload=WEAPONS[self.weapon]["reload"]

class Bullet:
    def __init__(self,x,y,a,dmg):
        self.x,self.y,self.a,self.damage=x,y,a,dmg
        self.speed=850;self.dead=False
    def update(self,dt,enemies):
        self.x+=math.cos(self.a)*self.speed*dt
        self.y+=math.sin(self.a)*self.speed*dt
        if not(0<self.x<WIDTH and 55<self.y<HEIGHT):self.dead=True
        for e in enemies:
            if not e.dead and math.hypot(self.x-e.x,self.y-e.y)<e.radius+5:
                e.hp-=self.damage;self.dead=True
                if e.hp<=0:e.dead=True
                break
    def draw(self):pygame.draw.circle(screen,(255,230,70),(int(self.x),int(self.y)),4)

class Enemy:
    def __init__(self,wave,boss=False):
        self.x=random.randint(30,WIDTH-30);self.y=random.randint(80,HEIGHT-30)
        self.dead=False;self.radius=22 if boss else 16
        if boss:
            self.rarity=random.choice(["Boss","Raid Boss","Final Boss"])
            mult={"Boss":8,"Raid Boss":30,"Final Boss":100}[self.rarity]
        else:
            self.rarity=weighted_rarity()
            mult=dict(RARITIES)[self.rarity]
        self.mutation=weighted_mutation()
        mut=dict(MUTATIONS)[self.mutation]
        scale=(1+wave*.12)
        self.max_hp=70*mult*mut*scale
        self.hp=self.max_hp
        self.damage=8*(mult**.25)*(mut**.35)
        self.speed=65+min(180,wave*4)
        self.color=(210,60,60) if boss else (150,80,130)
    def update(self,dt,player):
        dx,dy=player.x-self.x,player.y-self.y
        d=math.hypot(dx,dy) or 1
        self.x+=dx/d*self.speed*dt;self.y+=dy/d*self.speed*dt
        if d<30:player.hp-=self.damage*dt
    def draw(self):
        pygame.draw.circle(screen,self.color,(int(self.x),int(self.y)),self.radius)
        label=f"{self.rarity} | {self.mutation}"
        t=FONT.render(label,True,(240,240,240))
        screen.blit(t,(self.x-t.get_width()/2,self.y-38))

class ReportSystem:
    def __init__(self):self.reports=[]
    def submit(self,reporter,reported,reason,description=""):
        self.reports.append({"id":len(self.reports)+1,"reporter":reporter,
            "reported":reported,"reason":reason,"description":description,"status":"New"})
    def set_status(self,i,status,role):
        if role in ("ADMIN","OWNER"):
            for r in self.reports:
                if r["id"]==i:r["status"]=status

def xp_gain(data,amount):
    data["xp"]+=amount
    while data["xp"]>=data["level"]*100:
        data["xp"]-=data["level"]*100
        data["level"]+=1

def draw_text(s,x,y,big=False):
    screen.blit((BIG if big else FONT).render(s,True,(235,235,235)),(x,y))

def panel(title,lines):
    pygame.draw.rect(screen,(25,25,35),(170,85,760,530),border_radius=12)
    draw_text(title,205,110,True)
    for i,line in enumerate(lines):draw_text(line,205,165+i*31)

def main():
    player=Player();bullets=[];enemies=[];reports=ReportSystem()
    wave=0;to_spawn=0;spawn_timer=0;mode=None
    running=True
    while running:
        dt=clock.tick(120)/1000
        for ev in pygame.event.get():
            if ev.type==pygame.QUIT:running=False
            if ev.type==pygame.KEYDOWN:
                if ev.key==pygame.K_ESCAPE:mode=None
                if ev.key==pygame.K_F1:
                    reports.submit("Player","DemoPlayer","Cheating / Exploiting","Demo report")
                if ev.key==pygame.K_F2 and player.data["role"] in ("ADMIN","OWNER"):mode="admin"
                if ev.key==pygame.K_F3 and player.data["role"]=="OWNER":mode="owner"
                if ev.key==pygame.K_r:player.reload_weapon()
                if ev.key in (pygame.K_1,pygame.K_2,pygame.K_3,pygame.K_4,pygame.K_5):
                    player.weapon=ev.key-pygame.K_1
            if ev.type==pygame.MOUSEBUTTONDOWN and ev.button==1 and mode is None:
                player.shoot(bullets)

        if mode is None:
            player.update(dt)
            if to_spawn==0 and not enemies:
                wave+=1;to_spawn=5+wave*2;spawn_timer=0
                player.data["high_wave"]=max(player.data["high_wave"],wave)
            if to_spawn>0:
                spawn_timer-=dt
                if spawn_timer<=0:
                    enemies.append(Enemy(wave,wave%10==0 and to_spawn==1))
                    to_spawn-=1;spawn_timer=.15
            for b in bullets:b.update(dt,enemies)
            for e in enemies:e.update(dt,player)
            for e in [x for x in enemies if x.dead]:
                player.data["kills"]+=1;xp_gain(player.data,10)
                player.data["coins"]+=random.randint(5,25)
                if e.rarity in ("SECRET","ADMIN"):player.data["discovered"]+=1
            enemies=[e for e in enemies if not e.dead]
            bullets=[b for b in bullets if not b.dead]
            if player.hp<=0:
                player.hp=player.max_hp;wave=0;to_spawn=0;enemies=[]
            save_data(player.data)

        screen.fill((12,14,18))
        pygame.draw.rect(screen,(20,23,30),(0,0,WIDTH,55))
        draw_text(f"Wave {wave} | HP {int(player.hp)}/{int(player.max_hp)} | LV {player.data['level']} | XP {player.data['xp']} | Coins {player.data['coins']}",15,16)
        for b in bullets:b.draw()
        for e in enemies:e.draw()
        pygame.draw.circle(screen,(80,180,255),(int(player.x),int(player.y)),18)
        draw_text(f"{WEAPONS[player.weapon]['name']} | Ammo {player.ammo[player.weapon]}/{WEAPONS[player.weapon]['mag']}",15,HEIGHT-35)
        if mode=="admin":
            panel("ADMIN PANEL",[
                f"Reports: {len(reports.reports)}",
                "Review, resolve and dismiss reports",
                "Moderation: kick / investigate",
                "Spawn approved entities",
                "Control waves and debug tools",
                "F1 = demo report | ESC = close"
            ])
        elif mode=="owner":
            panel("OWNER PANEL",[
                "OWNER ACCESS",
                "Everything in Admin Panel",
                "Spawn ANY entity",
                "Force ANY rarity or mutation",
                "Manage Admin permissions",
                "Review all moderation actions",
                "Game configuration and debug controls",
                "Beyond Absolute Infinity enabled",
                "ESC = close"
            ])
        pygame.display.flip()
    save_data(player.data);pygame.quit()

if __name__=="__main__":main()
